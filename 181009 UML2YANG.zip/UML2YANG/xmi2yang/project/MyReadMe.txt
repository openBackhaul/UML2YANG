BgpModelUml_backup -> File used to generate BGP yang file.
mplsLdpModeluml_backup -> Filed used to generate LDP yang file.
MplsL3VpnModel.uml -> is taken from workspace-l3vpn
huawei-l3vpn.tree -> is what is converted to my UML.