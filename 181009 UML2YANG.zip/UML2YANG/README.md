# UML to YANG Mapping Tool
This UML to YANG Mapping Tool is developed according to the mapping rules defined in onf2015.261_Mapping_Gdls_UML-YANG.04 by OpenNetworkFoundation(ONF) IMP group. 

Please read "UML-Yang Mapping Tool User Guide" for instructions to run the tool.

xmi2yang tool-v1.3 is no longer in maintainenance, please use -v2.0 instead.

Introduction video to version 1.3 is uploaded to Youtube https://www.youtube.com/watch?v=6At3YFrE8Ag&feature=youtu.be.
Youku link http://v.youku.com/v_show/id_XMTQ4NDc2NDg0OA==.html