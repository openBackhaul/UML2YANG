#!/bin/bash
#
# build-yang
# Yang generation from UML including pruning and refactoring
#
# Copyright (C) 2016 highstreet technologies GmbH
# Author: Martin Skorupski <martin.skorupski@highstreet-technologies.com>

create_jail(){
   d=$1  
   echo "create_jail(): d is set to $d"
}

d=/apache.jail

echo "Before calling create_jail  d is set to $d"

create_jail "/home/apache/jail"

echo "After calling create_jail d is set to $d"