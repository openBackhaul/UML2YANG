#!/bin/bash
#
# build-yang
# Yang generation from UML including pruning and refactoring
#
# Copyright (C) 2016 highstreet technologies GmbH
# Author: Martin Skorupski <martin.skorupski@highstreet-technologies.com>
# Author: Shrikanth Malavalli Divakar <shrikanth.divakar@wipro.com>
# Author: Pavithra Thirumalai <pavithra.thirumalai1@wipro.com>
# Revision 1.1: Date:17-10-2018

# commandline parameters
args=$(getopt -l "odl:" -o "s:h" -- "$@")

eval set -- "$args"

while [ $# -ge 1 ]; do
        case "$1" in
                --)
                    # No more options left.
                    shift
                    break
                   ;;
                -o|--odl)
                        odl="$2"
                        shift
                        ;;
                -h)
                        echo "Display some help"
                        exit 0
                        ;;
        esac

        shift
done


function log {
    time="`TZ=\"Z\" date +%Y-%m-%dT%H:%M:%S,%3NZ`";
    tool="build-yang";
    info="INFO ";
    echo "$time | $tool | $info | $1";
}

#function delete-nodes {
#
#}


function post-processing {

	#This fix is required to make sure that date-and-time is as per the requirement.		
	sed -i -e "s/2010-11-20T14:00:00+01:00/2017-01-01T00:00:00.0Z/g" $1;   

	#delete all the import statements inserted using UML model. The script will later insert the correct import statements.  
	sed -i -e '/import core-model/{:a;N;/}/!ba};/prefix core-model/d' $1;  
	sed -i -e '/import g874/{:a;N;/}/!ba};/g874/d' $1;	
	sed -i -e '/import implementation-common-data-types/{:a;N;/}/!ba};/implementation-common-data-types/d' $1;  #This import statement is not at all required.

	#Append the initial revision infodelation to the YANG model. 
	sed -i -e '/revision/{:a;N;/}/!ba};/Version 1.1/a  revision 2017-03-24 {\r\n\t\tdescription "Initial version";\r\n\t\treference "ONF TR 532: A YANG Data Model for Wireless Networks.";\r\n\t}' $1;

	log "Add prefix to granulatity-period-type..";
	#Add prefix to the attributes wherever required.
	sed -i -e "s/type granularity-period-type;/type g:granularity-period-type;/g" $1;	
	
	#replace all "type string" with "type yang:date-and-time" wherever required.
	#sed -i -e "s/            leaf time-stamp {\n                type string;/            leaf time-stamp {\n                type yang:date-and-time;/g" $1;
	#sed -i -e "s/                leaf last-status-change {\n                    type string;/                leaf last-status-change {\n                    type yang:date-and-time;/g" $1;
	#The above lines don't seem to work on CYGWIN Environmen. Therefore using perl for multi line substitution.
	#NOTE: On Unix, \r mostly has no meaning. So, \n may suffice in such a case.

	log "update yang:date-and-time..";

	perl -i -0pe 's/\s*leaf\s*last-status-change\s*\{[\r\n]+\s*type\s*string\;/\r\n                leaf last-status-change \{\r\n                    type yang:date-and-time;/smg'  $1;
	perl -i -0pe 's/\s*leaf\s*time-stamp\s*\{[\r\n]+\s*type\s*string\;/\r\n\t\t\tleaf time-stamp \{\r\n\t\t\t\ttype yang:date-and-time;/smg'  $1;

	log "update Core-model associations..";

	#update the absolute path associations to core-model.
	sed -i -e "s/path '\/core-model:network-element\/core-model:ltp-ref-list\/core-model:uuid-list'/path '\/core-model:network-element\/core-model:ltp\/core-model:uuid'/g" $1;
	sed -i -e "s/path '\/core-model:network-element\/core-model:ltp-ref-list\/core-model:lp-list\/core-model:uuid-list'/path '\/core-model:network-element\/core-model:ltp\/core-model:lp\/core-model:uuid'/g" $1;  
	sed -i -e "s/path '\/core-model:forwarding-construct\/core-model:fc-port-list\/core-model:uuid-list'/path '\/core-model:forwarding-construct\/core-model:fc-port\/core-model:uuid'/g" $1;
	sed -i -e "s/path '\/core-model:forwarding-construct\/core-model:fc-switch-list\/core-model:uuid-list'/path '\/core-model:forwarding-construct\/core-model:fc-switch\/core-model:uuid'/g" $1;  

	#Following nodes require association with the core-model:universal-id
	log "update core-model:universal-id..";

	perl -i -0pe "s/\s*container\s*fixed-signal-ordering\s*\{[\r\n]+\s*uses\s*signal-ordering-type-g;[\r\n]+/\r\n\t\t\t\tleaf fixed-signal-ordering {\r\n\t\t\t\t\ttype core-model:universal-id;\r\n/smg"  $1;  #To update container fixed-signal-ordering
	perl -i -0pe "s/\s*container\s*transmission-mode-max\s*\{[\r\n]+\s*uses\s*transmission-mode-type-g;[\r\n]+/\r\n\t\t\t\tleaf transmission-mode-max {\r\n\t\t\t\t\ttype core-model:universal-id;\r\n/smg"  $1;  #To update container transmission-mode-max
	perl -i -0pe "s/\s*container\s*transmission-mode-min\s*\{[\r\n]+\s*uses\s*transmission-mode-type-g;[\r\n]+/\r\n\t\t\t\tleaf transmission-mode-min {\r\n\t\t\t\t\ttype core-model:universal-id;\r\n/smg"  $1;  #To update container transmission-mode-min
	
	# Replace all "default non" strings with default none" strings.
	log "update non key word with none";
	sed -i -e "s/default non;/default none;/g" $1; 	
		
	#insert status deprecated for attributes that are marked deprectated in the UML.
	log "update status deprecated";
	perl -i -0pe 's/\s*enum\s*if\s*\{/\r\n\t\t\t\tenum if \{\r\n\t\t\t\t\tstatus deprecated;/smg'  $1;  #To update enum if defined under loop-back-type
	perl -i -0pe 's/\s*enum\s*rf\s*\{/\r\n\t\t\t\tenum rf \{\r\n\t\t\t\t\tstatus deprecated;/smg'  $1;  #To update enum rf defined under loop-back-type 	
	perl -i -0pe 's/\s*leaf\s*duplex-distance\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "kHz";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf duplex-distance {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "kHz";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update duplex-distance

	log "update time2-state-nodes..";
	
	#TO DO: These commands can be further reduced to a single funciton and by passing the required attribute name as the parameter to the function.
	perl -i -0pe 's/\s*leaf\s*time2-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time2-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time2-states
	perl -i -0pe 's/\s*leaf\s*time4-states-s\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time4-states-s {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time4-states-s
	perl -i -0pe 's/\s*leaf\s*time4-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time4-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time4-states

	log "continue to update time-state-nodes..";
	perl -i -0pe 's/\s*leaf\s*time8-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time8-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time8-states
	perl -i -0pe 's/\s*leaf\s*time16-states-s\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time16-states-s {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time16-states-s
	perl -i -0pe 's/\s*leaf\s*time16-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time16-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time16-states

	log "continue to update time-state-nodes..";
	perl -i -0pe 's/\s*leaf\s*time32-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time32-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg' $1;  #To update time32-states
	perl -i -0pe 's/\s*leaf\s*time64-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time64-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg' $1;  #To update time64-states
	perl -i -0pe 's/\s*leaf\s*time128-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time128-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg' $1;  #To update time128-states
	
	log "continue to update time256-states..";
	perl -i -0pe 's/\s*leaf\s*time256-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time256-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg' $1;  #To update time256-states
	perl -i -0pe 's/\s*leaf\s*time512-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time512-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg' $1;  #To update time512-states
	perl -i -0pe 's/\s*leaf\s*time512-states-l\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time512-states-l {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time512-states-l							
	perl -i -0pe 's/\s*leaf\s*time1024-states-l\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time1024-states-l {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time1024-states-l
	
	log "continue to update time1024-states..";	
	perl -i -0pe 's/\s*leaf\s*time1024-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time1024-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time1024-states
	perl -i -0pe 's/\s*leaf\s*time2048-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time2048-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time2048-states
	perl -i -0pe 's/\s*leaf\s*time2048-states-l\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time2048-states-l {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time2048-states-l
	perl -i -0pe 's/\s*leaf\s*time4096-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time4096-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time4096-states

	log "continue to update time4096-states-l..";
	perl -i -0pe 's/\s*leaf\s*time4096-states-l\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time4096-states-l {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time4096-states-l
	perl -i -0pe 's/\s*leaf\s*time8192-states-l\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time8192-states-l {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time8192-states-l
	perl -i -0pe 's/\s*leaf\s*time8192-states\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "s";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\tleaf time8192-states {\r\n\t\t\t\ttype int32;\r\n\t\t\t\tunits "s";\r\n\t\t\t\tdefault -1;\r\n\t\t\t\tconfig false;\r\n\t\t\t\tstatus deprecated;/smg'  $1;  #To update time8192-states

	log "continue to update deprecated supported-alarms..";
	perl -i -0pe 's/\s*leaf\s*supported-alarms\s*\{[\r\n]+\s*type string;[\r\n]+\s*default "Supported alarms not yet defined.";[\r\n]+\s*config false;[\r\n]/\r\n\t\t\t\tleaf supported-alarms {\r\n\t\t\t\t\ttype string;\r\n\t\t\t\t\tdefault "Supported alarms not yet defined.";\r\n\t\t\t\t\tconfig false;\r\n\t\t\t\t\tstatus deprecated;/smg'  $1;  #To update supported-aladels
	perl -i -0pe 's/\s*leaf\s*tx-channel-bandwidth\s*\{[\r\n]+\s*type int32;[\r\n]+\s*units "kHz";[\r\n]+\s*default -1;/\r\n\t\t\t\tleaf tx-channel-bandwidth {\r\n\t\t\t\t\ttype int32;\r\n\t\t\t\t\tunits "kHz";\r\n\t\t\t\t\tdefault -1;\r\n\t\t\t\t\tstatus deprecated;/smg'  $1;  #To update tx-channel-bandwidth
	perl -i -0pe 's/\s*leaf\s*radio-signal-id\s*\{[\r\n]+\s*type string;[\r\n]+\s*default "Radio signal ID not yet defined.";/\r\n\t\t\t\tleaf radio-signal-id {\r\n\t\t\t\t\ttype string;\r\n\t\t\t\t\tdefault "Radio signal ID not yet defined.";\r\n\t\t\t\t\tstatus deprecated;/smg'  $1;  #To update radio-signal-id  

	log "continue to update deprecated modulation-min..";
	perl -i -0pe 's/\s*leaf\s*modulation-min\s*\{[\r\n]+\s*type int16;[\r\n]+\s*units "symbols";[\r\n]+\s*default -1;/\r\n\t\t\t\tleaf modulation-min {\r\n\t\t\t\t\ttype int16;\r\n\t\t\t\t\tunits "symbols";\r\n\t\t\t\t\tdefault -1;\r\n\t\t\t\t\tstatus deprecated;/smg'  $1;  #To update modulation-min
	perl -i -0pe 's/\s*leaf\s*modulation-max\s*\{[\r\n]+\s*type int16;[\r\n]+\s*units "symbols";[\r\n]+\s*default -1;/\r\n\t\t\t\tleaf modulation-max {\r\n\t\t\t\t\ttype int16;\r\n\t\t\t\t\tunits "symbols";\r\n\t\t\t\t\tdefault -1;\r\n\t\t\t\t\tstatus deprecated;/smg'  $1;  #To update modulation-max
	perl -i -0pe 's/\s*leaf\s*modulation-cur\s*\{[\r\n]+\s*type int16;[\r\n]+\s*units "symbols";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\t\tleaf modulation-cur {\r\n\t\t\t\t\ttype int16;\r\n\t\t\t\t\tunits "symbols";\r\n\t\t\t\t\tdefault -1;\r\n\t\t\t\t\tconfig false;\r\n\t\t\t\t\tstatus deprecated;/smg'  $1;  #To update modulation-cur

	log "continue to update deprecated code-rate-cur..";
	perl -i -0pe 's/\s*leaf\s*code-rate-cur\s*\{[\r\n]+\s*type int8;[\r\n]+\s*units "%";[\r\n]+\s*default -1;[\r\n]+\s*config false;[\r\n]/\r\n\t\t\t\tleaf code-rate-cur {\r\n\t\t\t\t\ttype int8;\r\n\t\t\t\t\tunits "%";\r\n\t\t\t\t\tdefault -1;\r\n\t\t\t\t\tconfig false;\r\n\t\t\t\t\tstatus deprecated;/smg' $1;  #To update code-rate-cur	
	perl -i -0pe "s/\s*leaf-list\s*logical-termination-point\s*\{[\r\n]+\s*type\s*leafref\s*{[\r\n]+\s*path\s*'\/core-model:network-element\/core-model:ltp\/core-model:uuid';[\r\n]+\s*}[\r\n]+/\r\n\t\t\t\tleaf-list logical-termination-point {\r\n\t\t\t\t\ttype leafref {\r\n\t\t\t\t\t\tpath '\/core-model:network-element\/core-model:ltp\/core-model:uuid';\r\n\t\t\t\t\t}\r\n\t\t\t\t\tstatus deprecated;\r\n/smg" $1;  #To update leaf-list logical-tedelination-point	
	perl -i -0pe "s/\s*container\s*structure-type\s*\{[\r\n]+\s*uses\s*tdm-structure-type-g;[\r\n]+/\r\n\t\t\t\tcontainer structure-type {\r\n\t\t\t\t\tuses tdm-structure-type-g;\r\n\t\t\t\t\tstatus deprecated;\r\n/smg" $1;  #To update container structure-type		

	#Delete all unwanted nodes.
	log "Delete all unwanted leaf nodes starting with -to-be-filled..";
	perl -i -0pe 's/\s*enum\s*-to-be-filled\s*\{[\r\n]+\s*description\s*"none";[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum -to-be-filled { description "none";} from the YANG model defined under medium-kind-type
	perl -i -0pe 's/\s*enum\s*non\s*\{[\r\n]+\s*description\s*"none";[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum non { description "none";} from the YANG model defined under loop-back-type
	perl -i -0pe 's/\s*enum\s*2-base-tl\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 2-base-tl  from the YANG model defined under pmd-name-type

	#log "continue to delete nodes 10-pass-ts and so on..";
	perl -i -0pe 's/\s*enum\s*10-pass-ts\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-pass-ts  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*1000-base-px10-d\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 1000-base-px10-d  from the YANG model defined under pmd-name-type
	
	log "Deleting 1000-base-px10-u...\n";
	perl -i -0pe 's/\s*enum\s*1000-base-px10-u\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 1000-base-px10-u  from the YANG model defined under pmd-name-type

	#log "continue to delete nodes 1000-base-px..";
	
	perl -i -0pe 's/\s*enum\s*1000-base-px20-d\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 1000-base-px20-u  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*1000-base-px20-u\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 1000-base-px20-d  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*1000-base-px30-d\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 1000-base-px30-u  from the YANG model defined under pmd-name-type

	#log "continue to delete nodes 1000-base-px30 and so on..";
	perl -i -0pe 's/\s*enum\s*1000-base-px30-u\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 1000-base-px30-d  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*1000-base-px40-d\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 1000-base-px40-u  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*1000-base-px40-u\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 1000-base-px40-d  from the YANG model defined under pmd-name-type

	#log "continue to delete nodes 10-gbase-w..";		
	perl -i -0pe 's/\s*enum\s*10-gbase-w\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/'  $1; # To delete enum 10-gbase-w  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*10-gbase-ew\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-gbase-ew  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*10-gbase-lw\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-gbase-lw  from the YANG model defined under pmd-name-type
	
	#log "continue to delete nodes 10-gbase-sw..";
	perl -i -0pe 's/\s*enum\s*10-gbase-sw\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-gbase-sw  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*10-1-gbase-prx-d1\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-1-gbase-prx-d1  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*10-1-gbase-prx-d2\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-1-gbase-prx-d2  from the YANG model defined under pmd-name-type
	
	#log "continue to delete nodes 10-1-gbase-prx-d3..";
	perl -i -0pe 's/\s*enum\s*10-1-gbase-prx-d3\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-1-gbase-prx-d3  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*10-1-gbase-prx-d4\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-1-gbase-prx-d4  from the YANG model defined under pmd-name-type
	
	
	perl -i -0pe 's/\s*enum\s*10-1-gbase-prx-u1\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-1-gbase-prx-u1  from the YANG model defined under pmd-name-type
	
	#log "continue to delete nodes 10-1-gbase-prx-u2..";
	perl -i -0pe 's/\s*enum\s*10-1-gbase-prx-u2\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-1-gbase-prx-u2  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*10-1-gbase-prx-u3\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-1-gbase-prx-u3  from the YANG model defined under pmd-name-type
	perl -i -0pe 's/\s*enum\s*10-1-gbase-prx-u4\s*\{[\r\n]+\s*description\s*.*[\r\n]+\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/' $1; # To delete enum 10-1-gbase-prx-u4  from the YANG model defined under pmd-name-type
	
	#log "continue to delete nodes rx-sync..";
	perl -i -0pe 's/\s*leaf\s*rx-sync-preference\s*\{[\r\n]+\s*type\s*string;[\r\n]+\s*description.*\(.*\).*\(.*\).*[\r\n\]+\s*802\.3\";[\r\n]+\s*\}\s*[\r\n]+/ \r\n/'  $1; #To delete the leaf rx-sync-preference from the YANG model defined under wire-interface-configuration-g
	perl -i -0pe 's/\s*leaf\s*rx-sync-role\s*\{[\r\n]+\s*type\s*string;[\r\n]+\s*config false;[\r\n]+\s*description.*\(.*\).*\(.*\).*[\r\n\]+\s*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/'  $1; #To delete the leaf rx-sync-role from the YANG model defined under wire-interface-configuration-g
	perl -i -0pe 's/\s*typedef\s*granularity-period-type\s*\{[\r\n\sa-z0-9\.\"\-;\{\}]+[\r\n]+\s*description\s*.*[\r\n]+\s*\}\s*[\r\n]+/ \r\n/'  $1; #To delete granularity-period-type as it is already defined in g.874.1-model	
	
	#Modify containers transmission-mode and transmission-mode-cur
	log "Modify container transmission mode as a leaf with a path reference.."
	perl -i -0pe "s/\s*container\s*transmission-mode\s*\{[\r\n\sa-z0-9\.\"\-;\{\}]+[\r\n]+\s*description\s*.*[\r\n]+\s*\}\s*[\r\n]+/\r\n\t\t\tleaf transmission-mode {\r\n\t\t\t\ttype leafref {\r\n\t\t\t\t\tpath '\/mw-air-interface-pac\/air-interface-capability\/supported-channel-plan-list\/transmission-mode-list\/transmission-mode-id';\r\n\t\t\t\t}\r\n\t\t\t\tconfig false;\r\n\t\t\t\tdescription \"Operated transmission mode.\";\r\n\t\t\t\t}\r\n/" $1; #To modify the container transmission-mode to leaf transmission-model with a path reference
	perl -i -0pe "s/\s*container\s*transmission-mode-cur\s*\{[\r\n\sa-z0-9\.\"\-;\{\}]+[\r\n]+\s*description\s*.*[\r\n]+\s*\}\s*[\r\n]+/\r\n\t\t\tleaf transmission-mode-cur {\r\n\t\t\t\ttype leafref {\r\n\t\t\t\t\tpath '..\/..\/air-interface-capability\/supported-channel-plan-list\/transmission-mode-list\/transmission-mode-id';\r\n\t\t\t\t}\r\n\t\t\t\tconfig false;\r\n\t\t\t\tdescription \"Currently operated transmission mode according to definitions in Capabilities.\";\r\n\t\t\t\t}\r\n/" $1; #To modify the container transmission-mode-cur to leaf transmission-mode-cur with a path reference
	
	log "  Post processed: $1";
}

log "Start";


log "Checking yang modules ...!";
cd "./Input";
files=(*.yang);

#update-deprecated "microwave-model.yang";
#delete-nodes "microwave-model.yang";

for item in ${files[*]}
do
  post-processing "$item"
  log "  $item";
  #pyang --lint "$item";
done
log "Yang modules checked!";

log "End";

