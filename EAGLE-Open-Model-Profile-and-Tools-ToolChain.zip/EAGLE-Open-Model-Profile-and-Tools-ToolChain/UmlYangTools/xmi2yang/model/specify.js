/**
 * Created by Administrator on 2017/4/1.
 */
function Specify(id, target,fileName){
    this.id = id;
    this.target=target;
    this.fileName = fileName;
}

module.exports = Specify;