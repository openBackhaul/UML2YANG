Contains UML models for testing the mapping tools
