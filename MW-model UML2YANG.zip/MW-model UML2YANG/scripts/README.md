# Scripts
yang2odl.sh
- a script which adds the revision to the yang file name of a source directory and stores the result in destination directory. Usage: yang2odl.sh <src-path> <dst-path>

yang2yin.sh
- a script which converts a yang files for a source directory to yin file and stores the result in destination directory.

yang2otherFormats.sh
- a script combining the scripts above to convert from yang files: yin-files, yang-odl-files and yin-odl-files. This script assumes the directory structure of this git repository.
