# Input folder
Copy the original eclipse papyrus uml files into this folder.
A copy of the input files will be "pruned and refactored" with xslt and from the result
yang modules will be generated.
